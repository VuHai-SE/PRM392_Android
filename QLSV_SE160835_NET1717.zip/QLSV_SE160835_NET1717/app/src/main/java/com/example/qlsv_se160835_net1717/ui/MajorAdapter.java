package com.example.qlsv_se160835_net1717.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.qlsv_se160835_net1717.R;
import com.example.qlsv_se160835_net1717.model.Major;

import java.util.List;

public class MajorAdapter extends ArrayAdapter<Major> {

    private Context context;
    private int resource;
    private List<Major> majors;
    private MajorAdapterListener listener;

    public interface MajorAdapterListener {
        void onEditClicked(Major major);
        void onDeleteClicked(Major major);
    }

    public MajorAdapter(Context context, int resource, List<Major> majors, MajorAdapterListener listener) {
        super(context, resource, majors);
        this.context = context;
        this.resource = resource;
        this.majors = majors;
        this.listener = listener;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(resource, parent, false);

        TextView textViewMajorName = view.findViewById(R.id.textViewMajorName);
        Button buttonEditMajor = view.findViewById(R.id.buttonEditMajor);
        Button buttonDeleteMajor = view.findViewById(R.id.buttonDeleteMajor);

        final Major major = majors.get(position);

        textViewMajorName.setText(major.getNameMajor());

        buttonEditMajor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onEditClicked(major);
            }
        });

        buttonDeleteMajor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onDeleteClicked(major);
            }
        });

        return view;
    }
}

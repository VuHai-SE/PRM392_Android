package com.example.qlsv_se160835_net1717;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.qlsv_se160835_net1717.database.DatabaseHelper;

import java.util.List;

public class MajorManagementActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ListView listViewMajors;
    private Button buttonAddMajor;
    private List<String> majorList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major_management);

        listViewMajors = findViewById(R.id.listViewMajors);
        buttonAddMajor = findViewById(R.id.buttonAddMajor);

        dbHelper = new DatabaseHelper(this);
        majorList = dbHelper.getAllMajorNames();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, majorList);
        listViewMajors.setAdapter(adapter);

        buttonAddMajor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddMajorDialog();
            }
        });

        listViewMajors.setOnItemLongClickListener((parent, view, position, id) -> {
            showEditDeleteMajorDialog(position);
            return true;
        });
    }

    private void showAddMajorDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_major, null);
        builder.setView(dialogView);

        final EditText editTextMajorName = dialogView.findViewById(R.id.editTextMajorName);
        final Button buttonAdd = dialogView.findViewById(R.id.buttonAddMajor);
        final AlertDialog dialog = builder.create();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String majorName = editTextMajorName.getText().toString().trim();

                if (majorName.isEmpty()) {
                    Toast.makeText(MajorManagementActivity.this, "Please enter a major name", Toast.LENGTH_SHORT).show();
                    return;
                }

                long result = dbHelper.addMajor(majorName);
                if (result == -1) {
                    Toast.makeText(MajorManagementActivity.this, "Failed to add major", Toast.LENGTH_SHORT).show();
                } else {
                    majorList.add(majorName);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(MajorManagementActivity.this, "Major added successfully", Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                }
            }
        });

        dialog.show();
    }

    private void showEditDeleteMajorDialog(int position) {
        String selectedMajor = majorList.get(position);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit/Delete Major");
        builder.setMessage("Do you want to edit or delete this major?");
        builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                showEditMajorDialog(selectedMajor, position);
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dbHelper.deleteMajor(selectedMajor);
                majorList.remove(position);
                adapter.notifyDataSetChanged();
                Toast.makeText(MajorManagementActivity.this, "Major deleted successfully", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    private void showEditMajorDialog(String selectedMajor, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_major, null);
        builder.setView(dialogView);

        final EditText editTextMajorName = dialogView.findViewById(R.id.editTextMajorName);
        editTextMajorName.setText(selectedMajor);
        final Button buttonAdd = dialogView.findViewById(R.id.buttonAddMajor);
        buttonAdd.setText("Update");
        final AlertDialog dialog = builder.create();

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String majorName = editTextMajorName.getText().toString().trim();

                if (majorName.isEmpty()) {
                    Toast.makeText(MajorManagementActivity.this, "Please enter a major name", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHelper.updateMajor(selectedMajor, majorName);
                majorList.set(position, majorName);
                adapter.notifyDataSetChanged();
                Toast.makeText(MajorManagementActivity.this, "Major updated successfully", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
